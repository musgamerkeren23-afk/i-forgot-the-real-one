# H4ll0 Reward Games
1. Upload semua isi folder ini ke repo GitHub (root repo, bukan folder di dalam folder).
2. Buka tab Actions > Build APK > tunggu hijau > download APK di Artifacts.
3. Password admin default: admin123 (GANTI di panel admin). Ganti juga SECRET di MainActivity.kt.
