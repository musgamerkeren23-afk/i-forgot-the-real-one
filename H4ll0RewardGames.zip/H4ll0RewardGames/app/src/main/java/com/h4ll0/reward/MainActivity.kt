package com.h4ll0.reward

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

class MainActivity : Activity() {
    // GANTI SECRET ini sebelum rilis! Dipakai buat bikin kode unlock.
    private val SECRET = "H4LL0-GANTI-INI"
    private val BG = Color.parseColor("#0D0D14")
    private val CARD = Color.parseColor("#1A1A26")
    private val ACC = Color.parseColor("#7C4DFF")
    private val GREEN = Color.parseColor("#00E676")
    private lateinit var sp: SharedPreferences
    private lateinit var root: LinearLayout
    private var user: String? = null
    private var timer: CountDownTimer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("h4ll0", 0)
        seed()
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(40), dp(18), dp(24))
        sv.addView(root)
        setContentView(sv)
        user = sp.getString("session", null)
        if (user != null && users().has(user!!)) home() else auth()
    }

    @Deprecated("back")
    override fun onBackPressed() { if (user != null) home() else auth() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun rp(n: Int) = "Rp " + NumberFormat.getInstance(Locale("in", "ID")).format(n)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun round(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }
    private fun screen() { timer?.cancel(); root.removeAllViews() }
    private fun tv(t: String, sz: Float = 16f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, dp(4), 0, dp(4))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, c: Int = ACC, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); background = round(c); setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun edit(h: String, pw: Boolean = false, num: Boolean = false) = EditText(this).apply {
        hint = h; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
        if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (num) inputType = InputType.TYPE_CLASS_NUMBER
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(CARD)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }
    private fun field(c: LinearLayout, label: String, value: String, num: Boolean = false): EditText {
        c.addView(tv(label, 12f, Color.GRAY))
        val e = edit(label, num = num); e.setText(value); c.addView(e); return e
    }

    // ---------- data ----------
    private fun users() = JSONObject(sp.getString("users", "{}")!!)
    private fun saveUsers(u: JSONObject) = sp.edit().putString("users", u.toString()).apply()
    private fun pts() = users().getJSONObject(user!!).getInt("pts")
    private fun addPts(n: Int) {
        val u = users(); val o = u.getJSONObject(user!!); o.put("pts", o.getInt("pts") + n); saveUsers(u)
    }
    private fun owns(id: String): Boolean {
        val a = users().getJSONObject(user!!).getJSONArray("own")
        for (i in 0 until a.length()) if (a.getString(i) == id) return true
        return false
    }
    private fun addOwn(id: String) {
        val u = users(); u.getJSONObject(user!!).getJSONArray("own").put(id); saveUsers(u)
    }
    // ---- langganan VIP ----
    private fun subEnd(): Long = users().getJSONObject(user!!).optLong("subEnd", 0)
    private fun isVip() = subEnd() > System.currentTimeMillis()
    private fun canAccess(id: String) = isVip() || owns(id)
    private fun addSub(days: Int) {
        val u = users(); val o = u.getJSONObject(user!!)
        val base = maxOf(System.currentTimeMillis(), o.optLong("subEnd", 0))
        o.put("subEnd", base + days * 86400000L)
        o.put("subN", o.optInt("subN", 0) + 1)
        saveUsers(u)
    }
    private fun plans() = JSONArray(sp.getString("plans2", "[]")!!)
    private fun savePlans(a: JSONArray) = sp.edit().putString("plans2", a.toString()).apply()
    private fun subCode(u: String, planId: String, n: Int) = sha("$SECRET|$u|sub|$planId|$n").take(8).uppercase()
    private fun fmtDate(t: Long) = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("in", "ID")).format(Date(t))
    private fun items() = JSONArray(sp.getString("items", "[]")!!)
    private fun saveItems(a: JSONArray) = sp.edit().putString("items", a.toString()).apply()
    private fun mk(id: String, name: String, price: Int, promo: Int, pts: Int, script: String) = JSONObject()
        .put("id", id).put("name", name).put("price", price).put("promo", promo).put("promoOn", true)
        .put("promoEnd", 1792601999000L).put("pts", pts).put("script", script)
    private fun seed() {
        if (!sp.contains("plans2")) {
            val desc = "Halo! Jika kau beli ini atau tukar koin untuk dapatkan langganan kau akan dapatkan fitur yang seru! Seperti:\n" +
                "• Pengumuman script baru di WA (dengan bot.)\n" +
                "• Bisa minta buat sesuatu\n" +
                "• Ajak mabar sama Dev/teams\n" +
                "• Dll yang makin seru!"
            val p = JSONArray()
            p.put(JSONObject().put("id", "vip").put("name", "Langganan VIP").put("days", 30)
                .put("price", 20000).put("promo", 10000).put("promoOn", true).put("promoEnd", 1792601999000L)
                .put("pts", 2500).put("desc", desc))
            sp.edit().putString("plans2", p.toString()).apply()
        }
        if (sp.contains("items")) return
        val a = JSONArray()
        a.put(mk("executor", "Script Executor", 10000, 5000, 500, "loadstring(game:HttpGet(\"https://raw.githubusercontent.com/musgamerkeren23-afk/Executor-H4ll0-Hub/refs/heads/main/executor.lua\"))()\n\nKey premium executor: VIP_FULL_ACCESS"))
        a.put(mk("explorer", "Script H4ll0 Explorer", 20000, 10000, 1000, "loadstring(game:HttpGet(\"https://raw.githubusercontent.com/musgamerkeren23-afk/h4ll0-explorer/refs/heads/main/Script/helloexplorer.lua\"))()\n\nKey explorer: DEX_H4LL0_2026"))
        sp.edit().putString("items", a.toString()).apply()
    }
    private fun isPromo(o: JSONObject) = o.getBoolean("promoOn") && o.getLong("promoEnd") > System.currentTimeMillis()
    private fun curPrice(o: JSONObject) = if (isPromo(o)) o.getInt("promo") else o.getInt("price")
    private fun code(u: String, id: String) = sha("$SECRET|$u|$id").take(8).uppercase()

    // ---------- auth ----------
    private fun auth() {
        user = null; screen()
        root.addView(tv("H4ll0 Reward Games", 28f, ACC, true))
        root.addView(tv("Main game, kumpulin poin, tukar script premium 🔥", 14f, Color.GRAY))
        val u = edit("Username"); val p = edit("Password", pw = true)
        root.addView(u); root.addView(p)
        root.addView(btn("Masuk") {
            val n = u.text.toString().trim().lowercase(); val us = users()
            if (us.has(n) && us.getJSONObject(n).getString("p") == sha(p.text.toString())) login(n)
            else toast("Username / password salah")
        })
        root.addView(btn("Daftar Akun Baru (bonus 100 poin)", Color.parseColor("#333355")) {
            val n = u.text.toString().trim().lowercase(); val us = users()
            when {
                n.length < 3 || p.text.length < 4 -> toast("Username min 3, password min 4 karakter")
                us.has(n) -> toast("Username sudah dipakai")
                else -> {
                    us.put(n, JSONObject().put("p", sha(p.text.toString())).put("pts", 100).put("own", JSONArray()))
                    saveUsers(us); login(n)
                }
            }
        })
        root.addView(btn("Panel Admin", Color.DKGRAY) { adminLogin() })
    }
    private fun login(n: String) { user = n; sp.edit().putString("session", n).apply(); home() }

    // ---------- home ----------
    private fun home() {
        screen()
        root.addView(tv("Halo, $user 👋", 22f, Color.WHITE, true))
        val c = card()
        c.addView(tv("Poin kamu", 13f, Color.GRAY)); c.addView(tv("⭐ ${pts()}", 32f, GREEN, true))
        root.addView(c)
        if (isVip()) root.addView(tv("💎 VIP aktif sampai ${fmtDate(subEnd())}", 13f, Color.parseColor("#FFD54F")))
        root.addView(btn("💎 Langganan VIP", Color.parseColor("#FF8F00")) { subs() })
        root.addView(btn("🎮 Main Game") { games() })
        root.addView(btn("🛒 Toko Script Premium") { store() })
        root.addView(btn("📜 Script Saya") { myScripts() })
        root.addView(btn("Keluar", Color.DKGRAY) { sp.edit().remove("session").apply(); auth() })
    }
    private fun back() = btn("← Kembali", Color.DKGRAY) { home() }

    // ---------- games ----------
    private fun games() {
        screen()
        root.addView(tv("Pilih Game", 24f, ACC, true))
        val c1 = card(); c1.addView(tv("⚡ Tap Challenge", 18f, Color.WHITE, true))
        c1.addView(tv("Tap sebanyak mungkin 10 detik. Maks +30 poin.", 13f, Color.GRAY))
        c1.addView(btn("Main") { tapGame() }); root.addView(c1)
        val c2 = card(); c2.addView(tv("🎯 Tebak Angka", 18f, Color.WHITE, true))
        c2.addView(tv("Tebak 1-10 dalam 3 kesempatan. +20 poin. Cooldown 60 detik.", 13f, Color.GRAY))
        c2.addView(btn("Main") { guessGame() }); root.addView(c2)
        root.addView(back())
    }
    private fun tapGame() {
        screen()
        var taps = 0; var started = false; var done = false
        val info = tv("Tekan tombol untuk mulai!", 16f)
        val cnt = tv("0", 56f, ACC, true); cnt.gravity = Gravity.CENTER
        root.addView(info); root.addView(cnt)
        root.addView(btn("MULAI / TAP!") {
            if (done) return@btn
            if (!started) {
                started = true
                timer = object : CountDownTimer(10000, 1000) {
                    override fun onTick(m: Long) { info.text = "Sisa ${m / 1000 + 1} detik" }
                    override fun onFinish() {
                        done = true; val g = minOf(taps / 10, 30); addPts(g)
                        info.text = "Selesai! $taps tap → +$g poin"
                    }
                }.start()
            }
            taps++; cnt.text = taps.toString()
        })
        root.addView(btn("← Kembali", Color.DKGRAY) { games() })
    }
    private fun guessGame() {
        val now = System.currentTimeMillis(); val last = sp.getLong("lastGuess", 0)
        if (now - last < 60000) { toast("Tunggu ${(60000 - (now - last)) / 1000} detik lagi"); return }
        sp.edit().putLong("lastGuess", now).apply()
        screen()
        val secret = Random().nextInt(10) + 1; var tries = 3
        val info = tv("Tebak angka 1-10 (3 kesempatan)", 16f)
        val e = edit("Angka", num = true)
        root.addView(info); root.addView(e)
        root.addView(btn("Tebak") {
            val g = e.text.toString().toIntOrNull() ?: return@btn
            if (tries <= 0) return@btn
            tries--
            when {
                g == secret -> { addPts(20); tries = 0; info.text = "BENAR! +20 poin 🎉" }
                tries == 0 -> info.text = "Habis! Jawabannya $secret"
                else -> info.text = (if (g < secret) "Terlalu kecil" else "Terlalu besar") + ", sisa $tries"
            }
            e.setText("")
        })
        root.addView(btn("← Kembali", Color.DKGRAY) { games() })
    }

    // ---------- store ----------
    private fun store() {
        screen()
        root.addView(tv("Toko Script Premium", 24f, ACC, true))
        root.addView(tv("Poin kamu: ${pts()}", 14f, Color.GRAY))
        val a = items()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val id = o.getString("id"); val name = o.getString("name")
            val c = card(); c.addView(tv(name, 18f, Color.WHITE, true))
            val price = curPrice(o)
            if (isPromo(o)) {
                c.addView(tv(rp(o.getInt("price")), 13f, Color.GRAY).apply { paint.isStrikeThruText = true })
                c.addView(tv("PROMO " + rp(o.getInt("promo")), 22f, GREEN, true))
                val left = (o.getLong("promoEnd") - System.currentTimeMillis()) / 60000
                c.addView(tv("⏳ Berakhir dalam ${left / 60} jam ${left % 60} menit", 12f, Color.parseColor("#FFB74D")))
            } else c.addView(tv(rp(price), 22f, Color.WHITE, true))
            if (canAccess(id)) c.addView(tv(if (owns(id)) "✅ Sudah dimiliki (lihat di Script Saya)" else "💎 Terbuka lewat VIP (lihat di Script Saya)", 13f, GREEN))
            else {
                c.addView(btn("Bayar ${rp(price)}") {
                    AlertDialog.Builder(this).setTitle("Cara Bayar")
                        .setMessage("1. Bayar ${rp(price)} ke owner\n2. Kirim bukti + username '$user' + item '$name'\n3. Owner kasih kode unlock, masukkan lewat tombol 'Masukkan Kode'")
                        .setPositiveButton("Hubungi Owner") { _, _ ->
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sp.getString("contact", "https://discord.com")!!))) }
                            catch (e: Exception) { toast("Link kontak belum valid") }
                        }.setNegativeButton("Tutup", null).show()
                })
                val cost = o.getInt("pts")
                c.addView(btn("Tukar $cost poin", Color.parseColor("#2E7D32")) {
                    if (pts() >= cost) { addPts(-cost); addOwn(id); toast("Berhasil! 🎉"); store() }
                    else toast("Poin kurang")
                })
                c.addView(btn("Masukkan Kode", Color.parseColor("#333355")) {
                    val e = edit("Kode unlock")
                    AlertDialog.Builder(this).setTitle("Kode Unlock").setView(e)
                        .setPositiveButton("OK") { _, _ ->
                            if (e.text.toString().trim().uppercase() == code(user!!, id)) { addOwn(id); toast("Terbuka! 🔓"); store() }
                            else toast("Kode salah")
                        }.setNegativeButton("Batal", null).show()
                })
            }
            root.addView(c)
        }
        root.addView(back())
    }
    private fun myScripts() {
        screen()
        root.addView(tv("Script Saya", 24f, ACC, true))
        val a = items(); var n = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!canAccess(o.getString("id"))) continue
            n++
            val c = card(); c.addView(tv(o.getString("name"), 18f, Color.WHITE, true))
            val s = TextView(this).apply { text = o.getString("script"); setTextColor(GREEN); textSize = 12f; setTextIsSelectable(true) }
            c.addView(s)
            c.addView(btn("Copy Script") {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("script", o.getString("script")))
                toast("Tersalin!")
            })
            root.addView(c)
        }
        if (n == 0) root.addView(tv("Belum punya script. Cek Toko!", 14f, Color.GRAY))
        root.addView(btn("💎 Langganan VIP (semua script)", Color.parseColor("#FF8F00")) { subs() })
        root.addView(back())
    }

    // ---------- langganan ----------
    private fun subs() {
        screen()
        root.addView(tv("Langganan VIP 💎", 24f, Color.parseColor("#FFD54F"), true))
        root.addView(tv("Semua script premium kebuka selama VIP aktif. Bisa beli pakai uang atau tukar poin.", 13f, Color.GRAY))
        val st = card()
        st.addView(tv("Status", 13f, Color.GRAY))
        if (isVip()) st.addView(tv("✅ VIP aktif sampai ${fmtDate(subEnd())}", 16f, GREEN, true))
        else st.addView(tv("Belum berlangganan", 16f, Color.WHITE, true))
        st.addView(tv("Poin kamu: ⭐ ${pts()}", 14f, GREEN))
        root.addView(st)
        val a = plans()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val id = o.getString("id"); val name = o.getString("name")
            val price = curPrice(o); val cost = o.getInt("pts")
            val c = card(); c.addView(tv(name, 18f, Color.WHITE, true))
            c.addView(tv("${o.getInt("days")} hari akses semua script", 13f, Color.GRAY))
            if (isPromo(o)) {
                c.addView(tv(rp(o.getInt("price")), 13f, Color.GRAY).apply { paint.isStrikeThruText = true })
                c.addView(tv("PROMO " + rp(price) + "  atau  ⭐ $cost poin", 20f, GREEN, true))
                c.addView(tv("⏳ Promo berakhir ${fmtDate(o.getLong("promoEnd"))}", 12f, Color.parseColor("#FFB74D")))
            } else c.addView(tv(rp(price) + "  atau  ⭐ $cost poin", 20f, GREEN, true))
            val d = o.optString("desc", "")
            if (d.isNotEmpty()) c.addView(tv(d, 13f, Color.LTGRAY))
            c.addView(btn("Beli ${rp(price)}") {
                AlertDialog.Builder(this).setTitle("Cara Bayar")
                    .setMessage("1. Bayar ${rp(price)} ke owner\n2. Kirim bukti + username '$user' + paket '$name'\n3. Owner kasih kode, masukkan lewat tombol 'Masukkan Kode'")
                    .setPositiveButton("Hubungi Owner") { _, _ ->
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sp.getString("contact", "https://discord.com")!!))) }
                        catch (e: Exception) { toast("Link kontak belum valid") }
                    }.setNegativeButton("Tutup", null).show()
            })
            c.addView(btn("Tukar $cost poin", Color.parseColor("#2E7D32")) {
                if (pts() < cost) toast("Poin kurang")
                else AlertDialog.Builder(this).setTitle("Tukar poin?")
                    .setMessage("$cost poin ditukar jadi $name.")
                    .setPositiveButton("Tukar") { _, _ -> addPts(-cost); addSub(o.getInt("days")); toast("VIP aktif! 💎"); subs() }
                    .setNegativeButton("Batal", null).show()
            })
            c.addView(btn("Masukkan Kode", Color.parseColor("#333355")) {
                val e = edit("Kode langganan")
                AlertDialog.Builder(this).setTitle("Kode Langganan").setView(e)
                    .setPositiveButton("OK") { _, _ ->
                        val n = users().getJSONObject(user!!).optInt("subN", 0)
                        if (e.text.toString().trim().uppercase() == subCode(user!!, id, n)) { addSub(o.getInt("days")); toast("VIP aktif! 💎"); subs() }
                        else toast("Kode salah / sudah dipakai")
                    }.setNegativeButton("Batal", null).show()
            })
            root.addView(c)
        }
        root.addView(back())
    }

    // ---------- admin ----------
    private fun adminLogin() {
        val e = edit("Password admin", pw = true)
        AlertDialog.Builder(this).setTitle("Panel Admin").setView(e)
            .setPositiveButton("Masuk") { _, _ ->
                if (e.text.toString() == sp.getString("adminPass", "admin123")) admin() else toast("Password salah")
            }.setNegativeButton("Batal", null).show()
    }
    private fun admin() {
        screen()
        root.addView(tv("Panel Admin 🛠", 24f, ACC, true))
        val uEdit = edit("Username target (buat kode unlock)"); root.addView(uEdit)
        val a = items()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val c = card()
            c.addView(tv(o.getString("id").uppercase(), 12f, ACC, true))
            val name = field(c, "Nama", o.getString("name"))
            val price = field(c, "Harga normal (Rp)", o.getInt("price").toString(), true)
            val promo = field(c, "Harga promo (Rp)", o.getInt("promo").toString(), true)
            val pt = field(c, "Harga dalam poin", o.getInt("pts").toString(), true)
            val hrs = field(c, "Promo berakhir dalam (jam) — kosong = tidak diubah", "", true)
            val on = CheckBox(this).apply { text = "Promo aktif"; setTextColor(Color.WHITE); isChecked = o.getBoolean("promoOn") }
            c.addView(on)
            val sc = field(c, "Isi script", o.getString("script"))
            c.addView(btn("Simpan") {
                o.put("name", name.text.toString()); o.put("price", price.text.toString().toIntOrNull() ?: 0)
                o.put("promo", promo.text.toString().toIntOrNull() ?: 0); o.put("pts", pt.text.toString().toIntOrNull() ?: 0)
                o.put("promoOn", on.isChecked); o.put("script", sc.text.toString())
                val h = hrs.text.toString().toLongOrNull()
                if (h != null) o.put("promoEnd", System.currentTimeMillis() + h * 3600000L)
                saveItems(a); toast("Tersimpan ✅"); admin()
            })
            c.addView(btn("Akhiri promo sekarang", Color.parseColor("#C62828")) {
                o.put("promoOn", false); saveItems(a); toast("Promo diakhiri"); admin()
            })
            c.addView(btn("Buat kode unlock untuk user", Color.parseColor("#333355")) {
                val u = uEdit.text.toString().trim().lowercase()
                if (u.isEmpty()) toast("Isi username target di atas")
                else AlertDialog.Builder(this).setTitle("Kode untuk $u")
                    .setMessage(code(u, o.getString("id"))).setPositiveButton("OK", null).show()
            })
            root.addView(c)
        }
        root.addView(tv("Paket Langganan VIP", 18f, Color.parseColor("#FFD54F"), true))
        val pl = plans()
        for (i in 0 until pl.length()) {
            val o = pl.getJSONObject(i); val c = card()
            c.addView(tv(o.getString("id").uppercase(), 12f, ACC, true))
            val name = field(c, "Nama paket", o.getString("name"))
            val days = field(c, "Durasi (hari)", o.getInt("days").toString(), true)
            val price = field(c, "Harga normal (Rp)", o.getInt("price").toString(), true)
            val promo = field(c, "Harga promo (Rp)", o.getInt("promo").toString(), true)
            val pt = field(c, "Harga dalam poin", o.getInt("pts").toString(), true)
            val hrs = field(c, "Promo berakhir dalam (jam) — kosong = tidak diubah", "", true)
            val on = CheckBox(this).apply { text = "Promo aktif"; setTextColor(Color.WHITE); isChecked = o.getBoolean("promoOn") }
            c.addView(on)
            val desc = field(c, "Deskripsi", o.optString("desc", ""))
            c.addView(btn("Simpan Paket") {
                o.put("name", name.text.toString()); o.put("days", days.text.toString().toIntOrNull() ?: 1)
                o.put("price", price.text.toString().toIntOrNull() ?: 0); o.put("promo", promo.text.toString().toIntOrNull() ?: 0)
                o.put("pts", pt.text.toString().toIntOrNull() ?: 0); o.put("promoOn", on.isChecked); o.put("desc", desc.text.toString())
                val h = hrs.text.toString().toLongOrNull()
                if (h != null) o.put("promoEnd", System.currentTimeMillis() + h * 3600000L)
                savePlans(pl); toast("Tersimpan ✅"); admin()
            })
            c.addView(btn("Akhiri promo sekarang", Color.parseColor("#C62828")) {
                o.put("promoOn", false); savePlans(pl); toast("Promo diakhiri"); admin()
            })
            c.addView(btn("Buat kode langganan untuk user", Color.parseColor("#333355")) {
                val u = uEdit.text.toString().trim().lowercase(); val us = users()
                if (u.isEmpty() || !us.has(u)) toast("Isi username target yang valid di atas")
                else AlertDialog.Builder(this).setTitle("Kode untuk $u")
                    .setMessage(subCode(u, o.getString("id"), us.getJSONObject(u).optInt("subN", 0)) + "\n\n(sekali pakai)")
                    .setPositiveButton("OK", null).show()
            })
            root.addView(c)
        }
        val c = card(); c.addView(tv("Pengaturan", 16f, Color.WHITE, true))
        val contact = field(c, "Link kontak (Discord/WA) untuk pembayaran", sp.getString("contact", "https://discord.com")!!)
        val pass = field(c, "Password admin baru", "")
        c.addView(btn("Simpan Pengaturan") {
            val ed = sp.edit().putString("contact", contact.text.toString())
            if (pass.text.length >= 4) ed.putString("adminPass", pass.text.toString())
            ed.apply(); toast("Tersimpan ✅")
        })
        root.addView(c)
        root.addView(btn("← Keluar Admin", Color.DKGRAY) { if (user != null) home() else auth() })
    }
}
